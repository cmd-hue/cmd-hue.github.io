w96.ui.MsgBoxSimple.error("Warning","There is no escape","OK")
