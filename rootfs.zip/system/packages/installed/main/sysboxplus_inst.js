// Ran upon package installation
w96.sys.execFile("C:/local/sysbox/sysboxplus.md")