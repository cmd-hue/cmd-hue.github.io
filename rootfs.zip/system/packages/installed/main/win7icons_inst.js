// Ran upon package installation
alert("Restart to apply the icon pack under Look and Feel.");