// Ran upon package installation
w96.sys.execFile("C:/local/micro96/README.txt")
alert("To complete the installation of this package, you must restart Windows 96.");