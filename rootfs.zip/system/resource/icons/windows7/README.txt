Windows 7 Icon Theme for Windows 96
----------------------------------------------------------
Icons (C) Microsoft Corporation
