# Welcome to Sysbox Plus!

Sysbox Plus! is a fork of Sysbox with more functionality. 

## What's it for?

You can use Sysbox Plus! for testing programs under Windows 96 without modifying your host installation. After restarting, all changes made are erased.

## Additions over vanilla Sysbox
Changed:
* Added icons to menu bar
* Added more resolutions

New features:
* ZIP sideloading
* Loading rootfs from a remote URL
* Simulating malicious actions (removing configuration, system folder, etc)
* New tools menu allowing quick access to most used applications
* New default rootfs with more functionality