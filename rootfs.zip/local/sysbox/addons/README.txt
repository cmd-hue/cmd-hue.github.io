Drop any .ZIP file in here and restart Sysbox Plus! to easily load it into the Windows 96 environment.

For more information, see the online documentation.